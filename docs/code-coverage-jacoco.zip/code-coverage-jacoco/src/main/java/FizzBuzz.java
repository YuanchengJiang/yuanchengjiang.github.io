/**
 * @author Petri Kainulainen
 */
public class FizzBuzz {

    public String getFizzBuzzWord(int number) {
        StringBuilder fizzBuzzWord = new StringBuilder();

        if (number % 3 == 0) {
            fizzBuzzWord.append("Fizz");
        }

        if (number % 5 == 0) {
            fizzBuzzWord.append("Buzz");
        }

        /* Oops? */
        if (number == 30) {
            fizzBuzzWord.append("Oops");
        }

        return (fizzBuzzWord.length() == 0) ? null : fizzBuzzWord.toString();
    }
}
