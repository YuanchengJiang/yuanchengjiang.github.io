FlowFusion uses pre-collected knowledges about PHP functions, classes and test cases to avoid parsing them during the runtime.


you need the following knowledge base:

apis.db: run `php function.php` first, then run `python3 function.py`

class.db: run `php class.php` first, then run `python3 class.py`

seeds.db: run `python3 seed-preprocessing.py`