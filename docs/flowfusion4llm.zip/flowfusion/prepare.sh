#!/bin/bash
mkdir phpt_seeds;
mkdir phpt_deps;
git clone https://github.com/php/php-src.git;
cd php-src;
git checkout 3786cff1f3f3d755f346ade78979976fee92bb48;
find ./ -name "*.phpt" > /tmp/flowfusion-prepare.log;
cd ..; python3 prepare.py;
